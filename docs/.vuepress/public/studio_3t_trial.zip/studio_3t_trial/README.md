# MongoDB Studio 3T 无限试用
## 0.有效版本
1. 2019.x.x
2. 最新2020.6.1
## 1.相关
* javaagent
* javassist
## 2. 使用
1. maven打包`mvn package`
2. jar包放置到`Studio 3T`安装目录
3. 修改`Studio 3T.vmoptions`文件, 添加`-javaagent`及jar包路径
```
示例: -javaagent:C:\Program Files\3T Software Labs\Studio 3T\studio_3t_crack-1.2.jar
```
## 3. 效果图
#### 效果图
![效果图](./image/result.png)
#### IDEA调试
![调试](./image/debug.png)
## 4. 备注
```bash
日志输出控制台: 3t.logToConsole
日志输出等级: 3t.logLevel
```

## 5.默认情况下,Linux系统用以上配置方式不行.我自己clone代码折腾了下,并没有做通用的

### 5.1 项目导入idea,按照idea调试图配置好配置

![配置图](./image/image.png)

### 5.2 修改CrackAgent类中getVersion方法

```java
File currentDir = new File("/opt/studio3t"); // File currentDir = new File(".");
```

### 5.3 mvn clean package打包项目

### 5.4 在idea中运行.此时正常运行起studio 3T,并且已经更改试用时间,但如果从studio3T安装目录执行启动程序的话,又会弹出30天试用期

### 5.5 直接暴力修改Studio-3T文件,原始文件太长,初步看了下大致内容就是使用java命令去运行data-man-mongodb-ent-2020.6.1.jar这个文件,所以干脆直接干掉.重新修改为下面内容:(studio_3t_crack-1.8.jar是5.3打包后的target目录下的jar文件)

```bash
#!/bin/sh

/opt/studio3t/jre/bin/java  -jar -javaagent:"/opt/studio3t/studio_3t_crack-1.8.jar" /opt/studio3t/data-man-mongodb-ent-2020.6.1.jar

```
    注:studio必须是jdk11的版本(11以上估计也行,没试过,本机刚好有8和11这2个版本的),刚开始采用jdk8,执行是报错版本不匹配.切换到11即可.所以命令中直接使用studio3T安装目录下的jre11.
    另外猜想不修改代码打包,直接使用现成的studio_3t_crack-1.8.jar,将文件拷贝到studio3t的安装目录下,然后直接修改Studio-3T文件也行.但是没试过
