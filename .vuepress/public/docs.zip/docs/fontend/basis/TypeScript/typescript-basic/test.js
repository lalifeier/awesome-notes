var hello = function (name) {
    return "hello " + name;
};
hello('world');
