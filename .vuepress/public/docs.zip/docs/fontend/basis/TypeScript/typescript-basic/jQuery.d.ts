declare var jQuery: (selctor: string) => any
