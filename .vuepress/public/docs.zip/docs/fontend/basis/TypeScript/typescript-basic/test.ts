const hello = (name: string) => {
  return `hello ${name}`
}

hello('world')
