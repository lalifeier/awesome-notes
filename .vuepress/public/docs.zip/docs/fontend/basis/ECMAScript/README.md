---
sidebar: auto
---

# ECMAScript

## ECMAScript2015(ES6)

### 声明

### 解构赋值

### 字符串扩展

### 正则扩展

### 数值扩展

### 函数扩展

### 数组扩展

### 对象扩展

### Symbol

### Set

### Map

### Proxy

### Reflect

### Promise

### Iterator

### Generator

### async

### Class

### Module
